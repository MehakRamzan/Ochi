import { motion } from "framer-motion";
import React, { useState } from "react";
import { Power4 } from "gsap";

function Feature() {
  const [isHoveringCard1, setHoveringCard1] = useState(false);
  const [isHoveringCard2, setHoveringCard2] = useState(false);

  const handleMouseEnterCard1 = () => {
    setHoveringCard1(true);
    setHoveringCard2(false);
  };

  const handleMouseLeaveCard1 = () => {
    setHoveringCard1(false);
  };

  const handleMouseEnterCard2 = () => {
    setHoveringCard2(true);
    setHoveringCard1(false);
  };

  const handleMouseLeaveCard2 = () => {
    setHoveringCard2(false);
  };

  return (
    <div className="w-full py-10 bg-zinc-900">
      <div className="px-20 py-20 border-b-[1px] pb-10 border-zinc-700">
        <h1 className='text-7xl font-["Neue_Montreal"] tracking-tight'>
          Featured Projects
        </h1>
      </div>
      <div className="px-20">
        <div className="cards w-full flex gap-10 mt-10">
          <div
            onMouseEnter={handleMouseEnterCard1}
            onMouseLeave={handleMouseLeaveCard1}
            className="card-container w-1/2 h-[75vh] relative"
          >
            {isHoveringCard1 && (
              <h1
                className="text-[#CDEA68] absolute flex left-full text-8xl z-50 -translate-x-1/2 top-1/2 -translate-y-1/2 leading-none"
                style={{ fontFamily: "Test Founders Gtsk X-Cond SmB" }}
              >
                {"FYDE".split("").map((item, index) => (
                  <motion.span
                    initial={{ y: "100%" }}
                    animate={{ y: "0" }}
                    transition={{ ease: Power4.easeInOut, delay: index * 0.06 }}
                    className="inline-block"
                    key={index}
                  >
                    {item}
                  </motion.span>
                ))}
              </h1>
            )}
            <div className="card w-full h-full rounded-xl overflow-hidden">
              <img
                src="https://ochi.design/wp-content/uploads/2023/10/Fyde_Illustration_Crypto_2-663x551.png"
                alt=""
                className="h-full w-full bg-cover"
              />
            </div>
          </div>
          <div className="headings absolute">
            <h1 className=""></h1>
          </div>
          <div
            onMouseEnter={handleMouseEnterCard2}
            onMouseLeave={handleMouseLeaveCard2}
            className="card-container w-1/2 h-[75vh] relative"
          >
            {isHoveringCard2 && (
              <h1
                className="text-[#CDEA68] absolute overflow-hidden mr-10 right-full flex text-8xl z-50 translate-x-1/2 top-1/2 -translate-y-1/2 leading-none"
                style={{ fontFamily: "Test Founders Gtsk X-Cond SmB" }}
              >
                {"VISE".split("").map((item, index) => (
                  <motion.span
                    initial={{ y: "100%" }}
                    animate={{ y: "0" }}
                    transition={{ ease: Power4.easeInOut, delay: index * 0.06 }}
                    className="inline-block"
                    key={index}
                  >
                    {item}
                  </motion.span>
                ))}
              </h1>
            )}
            <div className="card w-full h-full rounded-xl overflow-hidden">
              <img
                src="https://ochi.design/wp-content/uploads/2022/09/Vise_front2-663x551.jpg"
                alt=""
                className="h-full w-full bg-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Feature;