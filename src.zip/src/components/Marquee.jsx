import React from 'react';
import { motion } from "framer-motion";



function Marquee() {

  return (
    <div data-scroll data-scroll-section className='w-full py-20 rounded-tl-3xl rounded-tr-3xl bg-[#004D43] overflow-hidden'>
      <div className="text border-t-[1px] border-b-[1px] border-zinc-300  flex whitespace-nowrap overflow-hidden ">
       
          <motion.h1
          initial = {{x:'0'}}
          animate = {{x: "-100%"}}
          transition={{ease: "linear" , repeat: Infinity , duration: 5 }}
          className="text-[27vw] leading-none uppercase -mt-[10vh] -mb-[4vh] pr-20" style={{ fontFamily: 'Test Founders Gtsk X-Cond SmB' }}>
            we are ochi 
          </motion.h1>
          <motion.h1
         initial = {{x:'0'}}
         animate = {{x: "-100%"}}
         transition={{ease: "linear" , repeat: Infinity , duration: 5 }}
          className="text-[27vw] leading-none uppercase  -mt-[10vh]  -mb-[4vh] pr-20" style={{ fontFamily: 'Test Founders Gtsk X-Cond SmB' }}>
            we are ochi 
          </motion.h1>
      
      </div>
    </div>
    
  );
}

export default Marquee;
