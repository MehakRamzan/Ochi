import { motion } from "framer-motion";
import React from "react";
import { FaArrowUpLong } from "react-icons/fa6";


function Landing() {

  return (
    <div data-scroll data-scroll-speed = "-.3"  className="w-full h-screen bg-zinc-900 border-t2 ">
      <div className="textstructure px-20 py-[8vh] ">
        {["We Create", "Eyes Opening", "Presentations"].map((item, index) => {
          return (
            <div className="w-fit flex">
              {index === 1 && (
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: "9vw" }}
                  transition={{ ease: [0.87, 0, 0.13, 1] , duration: 1}}
                  className="w-[8vw] h-[5.7vw]  relative top-[1.1vw] rounded-md mr-[1vw]  "
                >
                  {" "}
                  <img
                    className="rounded-md mt-1"
                    src="https://ochi.design/wp-content/uploads/2022/04/content-image01.jpg"
                    alt=""
                  />{" "}
                </motion.div>
              )}

              <div className="masker overflow-hidden ">
                <h1
                  className=" flex items-center h-full text-[9vw] uppercase leading-[7vw]"
                  style={{ fontFamily: "Test Founders Gtsk X-Cond SmB" }}
                >
                  {item}
                </h1>
              </div>
            </div>
          );
        })}
      </div>
      <div className="border-t-[1px] border-zinc-800  mt-20 px-20 py-10 flex justify-between align-middle">
        {[
          "For Public and Private Companies",
          "From the first pitch to IPO",
        ].map((item, index) => (
          <p className="text-md font-light tracking-tight leading-none">
            {item}
          </p>
        ))}

        <div className="start flex items-center gap-5 -mt-1 ">
          <div className="px-5 py-2 border-[1px] rounded-full border-zinc-500 font-light uppercase text-md ">
            Start the project{" "}
          </div>
          <div className=" px-5 py-5 w-3 h-3 rounded-full flex items-center justify-center border-[2px] border-zinc-500 ">
            <span className="rotate-[45deg]">
              <FaArrowUpLong />
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Landing;


